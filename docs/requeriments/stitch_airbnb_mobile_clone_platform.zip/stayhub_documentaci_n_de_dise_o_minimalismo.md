# Guía de Estilo: Minimalismo Arquitectónico - StayHub

Esta guía documenta la identidad visual premium y minimalista desarrollada para **StayHub**. El objetivo es proporcionar una base sólida y coherente para que todo el equipo mantenga la integridad del diseño en futuras pantallas y funcionalidades.

## 🎨 Paleta de Colores

El sistema utiliza un enfoque monocromático de alto contraste que permite que las fotografías de las propiedades sean las protagonistas.

| Color | Valor Hex | Uso Principal |
| :--- | :--- | :--- |
| **Pure White** | `#FFFFFF` | Fondos de superficie, contenedores principales. |
| **Soft Gray** | `#F9F9F9` | Fondos de pantalla, secciones secundarias. |
| **Mist** | `#DADADA` | Bordes sutiles, divisores, estados desactivados. |
| **Charcoal** | `#1A1A1A` | Texto principal, iconos, botones de acción (CTA). |
| **Medium Gray** | `#717171` | Texto secundario, etiquetas, metadatos. |

## ✍️ Tipografía

Hemos seleccionado **Plus Jakarta Sans** por su claridad moderna y excelente legibilidad en dispositivos móviles.

- **Headlines:** Peso *Bold* (700) o *SemiBold* (600). Tracking ligero de `-0.02em`.
- **Body:** Peso *Regular* (400). Interlineado generoso (`leading-relaxed`) para mejorar la lectura.
- **Labels:** Peso *Medium* (500), tamaño pequeño, a veces en mayúsculas para jerarquía.

## 📐 Principios de Diseño

1. **Espacio en Blanco (Negative Space):** El aire es un elemento de diseño. No satures la pantalla; permite que el contenido respire.
2. **Jerarquía Visual:** Usa el peso de la fuente y el contraste (Charcoal vs Medium Gray) en lugar de colores vibrantes para guiar el ojo.
3. **Iconografía de Línea Fina:** Iconos minimalistas de trazo delgado (outline) para mantener la ligereza visual.
4. **Bordes Sutiles:** Evita sombras pesadas. Prefiere bordes finos de 1px en color `Mist` para separar secciones.
5. **Redondez:** Se utiliza un radio de curvatura suave (`rounded-xl` o 12px-16px) para suavizar la estética industrial.

## 🧱 Componentes Clave

- **Botones:** Fondo `Charcoal` con texto `White`. Sin bordes, esquinas suavemente redondeadas.
- **Tarjetas:** Sin bordes o con borde `Mist` muy fino. Énfasis total en la imagen.
- **Inputs:** Fondo `Soft Gray` con tipografía clara y minimalista.

---
*StayHub - Proyecto de Programación de Aplicaciones Movibles 2*

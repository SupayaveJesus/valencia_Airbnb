---
name: Architectural Minimalist
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#444748'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#4f6354'
  on-secondary: '#ffffff'
  secondary-container: '#d2e8d5'
  on-secondary-container: '#55695a'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1a1c1c'
  on-tertiary-container: '#838484'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474746'
  secondary-fixed: '#d2e8d5'
  secondary-fixed-dim: '#b6ccba'
  on-secondary-fixed: '#0d1f14'
  on-secondary-fixed-variant: '#384b3d'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c6'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '300'
    lineHeight: '1.6'
    letterSpacing: 0.01em
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '300'
    lineHeight: '1.6'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-margin: 24px
  gutter: 16px
  section-gap-desktop: 80px
  section-gap-mobile: 48px
---

## Brand & Style
The brand personality is rooted in "quiet luxury"—a sophisticated, architectural approach that prioritizes negative space and high-end photography over decorative elements. The goal is to evoke a sense of effortless travel through a calm, gallery-like interface.

The design style is **High-Contrast Minimalism**. It utilizes a monochrome foundation to allow property and destination imagery to serve as the primary visual driver. Elements are structured with a geometric precision that feels both modern and timeless.

**Key Principles:**
- **Clarity over Ornamentation:** Every element must have a functional purpose.
- **Visual Breathing Room:** Generous white space (or dark space in dark mode) to reduce cognitive load.
- **Architectural Hierarchy:** Strong vertical and horizontal alignment reflecting structural stability.

## Colors
The palette is intentionally restrained to maintain a premium, editorial feel. 

- **Primary (#1A1A1A):** Used for typography, icons, and primary structural lines. It provides the "ink" on the page.
- **Secondary/Accent (#3A4D3F):** A deep Forest Green used sparingly for critical calls-to-action (e.g., "Book Now") and success states. 
- **Neutral/Base (#FAFAFA):** The primary background color, providing a soft, warm-white canvas that feels more luxurious than pure white.
- **Subtle Accent (#E5E5E5):** Used for hair-line borders and secondary backgrounds (like search bars or disabled states).

Avoid gradients. Use solid fills to maintain the architectural integrity of the design.

## Typography
Typography is the cornerstone of this design system. We pair **Plus Jakarta Sans** for headlines to provide a modern, geometric touch with **Inter** for body text to ensure maximum legibility and a technical, clean feel.

**Application Rules:**
- **Headlines:** Use tight letter-spacing for large display text to create a high-fashion, editorial look.
- **Body:** Body text should always be light (`300` weight) with generous line-height to maintain the "airy" feel of the brand.
- **Labels:** Use uppercase for small labels and navigation items to create a rhythmic contrast against the light body text.

## Layout & Spacing
The layout follows a **Fluid Grid** model with strict adherence to an 8px square rhythm. 

- **Desktop:** 12-column grid with a max-width of 1440px. 24px margins.
- **Mobile:** 4-column grid with 16px gutters and 24px side margins.
- **Rhythm:** Vertical spacing between sections should be aggressive. Use `section-gap-desktop` to ensure the content doesn't feel cramped.

Layouts should favor asymmetry in photo placement to mimic high-end architectural magazines, while keeping functional UI elements (like filters and forms) strictly aligned to the grid.

## Elevation & Depth
Depth is communicated through **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows.

- **Surface Levels:** The primary background is `#FAFAFA`. Cards or secondary containers can use pure `#FFFFFF` to subtly lift them, or a 1px border of `#E5E5E5`.
- **Shadows:** Use only one "Ambient Shadow" level for floating elements (like modals or dropdowns): `0px 12px 32px rgba(0, 0, 0, 0.04)`. This shadow should be barely perceptible, serving to soften the edge rather than create height.
- **Lines:** Use 1px solid lines in `#E5E5E5` for dividers. Avoid using shadows for separation when a thin line or whitespace can achieve the same result.

## Shapes
The shape language combines the structural rigidity of thin lines with the approachability of large corner radii.

- **Primary Radius:** 16px (`rounded-lg`) is the standard for cards, buttons, and input fields.
- **Extreme Radius:** Images and featured containers should use 24px (`rounded-xl`) to create a soft, premium frame for photography.
- **Iconography:** Use a 1.5pt or 2pt stroke weight with slightly rounded caps to match the typography. Icons should never be filled unless they are in an "active" state.

## Components
Consistent component styling reinforces the "Quiet Luxury" aesthetic.

- **Buttons:** 
    - *Primary:* Solid `#1A1A1A` with white text. 16px radius. No shadow.
    - *Secondary:* 1px border of `#1A1A1A` with transparent background.
    - *CTA:* Deep Forest Green (`#3A4D3F`) reserved for "Finalize Booking."
- **Inputs:** 
    - Flat backgrounds (`#FAFAFA`) with a 1px bottom border in `#1A1A1A` or a full 1px border in `#E5E5E5`.
    - Focus state: Border darkens to `#1A1A1A`. No "glow" effects.
- **Cards:** 
    - Borderless with 24px padding. 
    - Use high-quality imagery that bleeds to the top and sides of the card with a 24px top-radius.
- **Chips/Filters:** 
    - Pill-shaped with `#E5E5E5` backgrounds. Selected states flip to `#1A1A1A` with white text.
- **Lists:** 
    - Minimalist separators (1px `#E5E5E5`) with generous 20px vertical padding between items.
- **Navigation:** 
    - A persistent "Thin Header" with 1px bottom border. Navigation links use `label-md` styling.